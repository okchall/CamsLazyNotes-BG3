# Gale Companion Build Guide (Wizard, Evocation)

## Table of contents
- [[#Build snapshot]]
- [[#Character creation (COMPANION-SAFE)]]
- [[#Level-by-level progression (Wizard 1 → 12)]]
- [[#Act-by-Act Add-ons]]
  - [[#Act 1 — Best gear]]
  - [[#Act 2 — Best gear]]
  - [[#Act 3 — Best gear]]
- [[#Permanent bonuses (by Act)]]
- [[#Best consumables / items (single-use)]]
- [[#Optional: Illithid powers (if using tadpoles)]]
- [[#Optional: Alternative build route (from the guide)]]

## Build snapshot

### Core playstyle in one sentence
* The companion is deployed from the back line to cast massive, controlled area-of-effect abilities, guaranteeing damage to enemies while safely navigating around friendly units.## 

## About Companion
* Gale is a **Human Wizard**.
* His primary role is a high-damage, flexible **Evocation spellcaster**.
* He prioritizes maximizing his Intelligence score to ensure his powerful area attacks land successfully and deal maximum damage.



### Party role
* **Artillery/Controller:** The primary source of ranged magical damage and battlefield control.

---

# Character creation (COMPANION-SAFE)

### Race
Human

### Background
(Not specified in source — companion character)

### Ability score rolls (Starting array)
* Strength: 8
* Dexterity: 14
* Constitution: 14
* Intelligence: 17
* Wisdom: 12
* Charisma: 10

### Starting proficiencies
* **Saves:** Intelligence, Wisdom
* **Skills:** Insight, Investigation

---

# Level-by-level progression (Wizard 1 → 12)

**Lvl 1 (Wizard 1)**
* **Gain:** Wizard Class
* **Play Style:** Starts as a general utility caster; relies on Cantrips and a few low-level learned abilities for survival and support.

**Lvl 2 (Wizard 2)**
* **Gain:** School of Evocation Subclass (Allows safe area-of-effect abilities that spare allies)
* **Play Style:** Becomes a dedicated damage caster, focused on deploying area damage abilities without the risk of harming the party.

**Lvl 3 (Wizard 3)**
* **Gain:** Access to Level 2 ability slots
* **Play Style:** Gains abilities for improved positioning and control.

**Lvl 4 (Wizard 4)**
* **Gain:** Feat: Ability Improvement (+2 INT, increasing INT to 19)
* **Play Style:** Gains a significant bump to spell attack and save Difficulty Class (DC), making powerful abilities more reliable.

**Lvl 5 (Wizard 5)**
* **Gain:** Access to Level 3 ability slots
* **Play Style:** Unlocks access to the first high-damage, fight-changing area abilities.

**Lvl 6 (Wizard 6)**
* **Gain:** Access to Level 3 ability slots
* **Play Style:** Increases ability slot resources for sustained offense.

**Lvl 7 (Wizard 7)**
* **Gain:** Access to Level 4 ability slots
* **Play Style:** Gains powerful control and damage options.

**Lvl 8 (Wizard 8)**
* **Gain:** Feat: Spell Sniper
* **Play Style:** Improves critical hit chance for ability rolls, while ignoring enemy cover, increasing damage reliability.

**Lvl 9 (Wizard 9)**
* **Gain:** Access to Level 5 ability slots
* **Play Style:** Unlocks even more devastating area and single-target magical abilities.

**Lvl 10 (Wizard 10)**
* **Gain:** Access to Level 5 ability slots
* **Play Style:** Focuses on using high-damage abilities to clear groups quickly.

**Lvl 11 (Wizard 11)**
* **Gain:** Access to Level 6 ability slots
* **Play Style:** Unlocks the most powerful abilities available for unmatched offensive output.

**Lvl 12 (Wizard 12)**
* **Gain:** Feat: Ability Improvement (+1 INT, increasing INT to 20)
* **Play Style:** Reaches maximum proficiency and power (20 INT), cementing the companion as the party's magical cornerstone.

---

# Act-by-Act Add-ons

## Act 1 — Best gear
| Item Slot | Item Name | Where to get |
| :--- | :--- | :--- |
| **Weapon (Staff)** | Staff of Arcane Blessing | Drops from a specific enemy in the Act 1 area. |
| **Body (Robe)** | Robe of Summer | Sold by a Tiefling merchant in the Emerald Grove. |
| **Gloves** | Gloves of Cinder and Sizzle | Sold by an NPC in the Goblin Camp. |
| **Amulet** | Amulet of Misty Step | Found in a chest in the Shattered Sanctum. |
| **Ring** | Ring of Protection | Quest reward from Mol. |

## Act 2 — Best gear
| Item Slot | Item Name | Where to get |
| :--- | :--- | :--- |
| **Weapon (Staff)** | Markoheshkir | Found in Ramazith’s Tower. |
| **Body (Robe)** | Potent Robe | Reward from the Nightsong questline (from the Tiefling). |
| **Gloves** | Quickspell Gloves | Sold by an NPC in Moonrise Towers. |
| **Amulet** | Amulet of Greater Health | Found in the Archive of the House of Hope. |
| **Boots** | Helldusk Boots | Found in a chest in the House of Hope. |

## Act 3 — Best gear
| Item Slot | Item Name | Where to get |
| :--- | :--- | :--- |
| **Head (Hat)** | Birthright | Sold by Sorcerous Sundries. |
| **Body (Robe)** | Robe of the Weave | Found in a specific vault in Sorcerous Sundries. |
| **Weapon (Staff)** | Markoheshkir | Found in Ramazith’s Tower (remains best in slot). |
| **Ring 1** | Ring of Regeneration | Sold by an NPC in the Lower City. |
| **Ring 2** | Ketheric's Ring | Found in a specific location in the Lower City. |

---

# Permanent bonuses (by Act)
- **Auntie Ethel's Hair** — *+1 to an Ability Score*
- **Volper's Eye** — *Permanent condition: See Invisibility*
- **Statue of the Gods** — *+2 to Saving Throws*
- **Loviatar's Blessing** — *+2 to Attack Rolls and Saving Throws*

---

# Best consumables / items (single-use)
- **Elixir of Bloodlust** — once per turn on kill: **5 temp HP** + **additional action**
- **Potion of Speed** — extra action, +2 AC, advantage on DEX saves, double movement
- **Elixir of Hill Giant Strength** — sets STR to **21** (until Long Rest)
- **Drow Poison** — weapon poison (CON save or becomes Poisoned/Asleep)
- **Potion of Flying** — flying speed for 1 hour
- **Elixir of Heroism** — 10 temp HP + Blessed (until Long Rest)
- **Potion of Greater Healing** — 4d4 + 4 healing
- **Oil of Accuracy** — weapon coating: **+2 Attack Rolls**
- **Elixir of Vigilance** — **+5 initiative**; can’t be Surprised

---

## Optional: Illithid powers (if using tadpoles)
- **Luck of the Far Realms** — turn a successful hit into a Critical Hit
- **Cull of the Weak** — execute low-HP enemies; nearby creatures take Psychic damage
- **Psionic Backlash** — reaction Psychic damage when an enemy casts a spell
- **Blackhole** — area pull that slows targets
- **Repulsor** — massive area knockback (can hit friendlies)

(Not specified in source for companion eligibility, but generally accessible)

---

## Optional: Alternative build route (from the guide)
The source explicitly presents an alternative companion setup for Gale:
* **Sorcerer/Wizard Multiclass (Sorc 1 → Wizard 11)**
    * This path is focused on leveraging Metamagic (Gained at Sorcerer 1) to enhance the effectiveness of his Wizard abilities. It allows for highly customized ability usage in combat, such as quickening or twinning powerful effects.