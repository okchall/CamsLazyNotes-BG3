
Welcome to **Cam’s Lazy Notes for Baldur’s Gate 3**.
>This is a **rough** list of "guides". It's for lazy or new players, who want a little bit of handholding / recommended setups to get through. I'm not claiming this is meta or anything. YMMV.

## Where to go (on the left)

- **Class Guides** — builds for subclasses  
- **Companion Guides** — builds for companions 
- **Game Walkthrough** — story progression *(tailored for Honor Mode)*

## How to use this

- Use the **folders on the left** to browse.
- Use **Ctrl + O** to quickly search and open any note.

## Updates

> This vault auto-updates when you open it, so you should always have the latest version.

> **Note:** If you keep personal progress notes, and you REALLY don't want to lose your checked boxes, store them in a separate folder (like `My Notes`) so updates don’t overwrite them. Or don't. I don't care.

## Credits

>https://deltiasgaming.com for class & companion guides
>Celador for their Steam guide through Honor Mode:
> 	(https://steamcommunity.com/sharedfiles/filedetails/?id=3045311496) 
>LLMs for help formatting all this information in a format I wanted.
>Matt, Steven, & Michael for inspiration.
>Me for putting it all together.

