
Welcome to **Cam’s Lazy Notes for Baldur’s Gate 3**.

## Where to go (on the left)

- **Class Guides** — builds for subclasses  
- **Companion Guides** — builds for companions 
- **Game Walkthrough** — story progression *(tailored for Honor Mode)*

## How to use this

- Use the **folders on the left** to browse.
- Use **Ctrl + O** to quickly search and open any note.

## Updates

> This vault auto-updates when you open it, so you should always have the latest version.

> **Note:** If you keep personal progress notes, and you REALLY don't want to lose your checked boxes, store them in a separate folder (like `My Notes`) so updates don’t overwrite them. Or don't. I don't care.
